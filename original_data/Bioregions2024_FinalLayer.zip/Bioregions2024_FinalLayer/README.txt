Data owner: Prof. Maycira Costa, University of Victoria, BC, Canada
Contact: maycira@uvic.ca

Lincese and copyright:
This is an open access article under the CC BY-NC-ND 4.0 license
(Creative Commons Attribution-NonCommercial-NoDerivatives 4.0 International;
http://creativecommons.org/licenses/by-nc-nd/4.0/).

0079-6611/Crown Copyright © 2024 Published by Elsevier Ltd.

Source paper:
Konik, M., Peña, M.A. Hirawake, T., Hunt, B.P.V., Vishnu, P.S., Eisner, L.B., Bracher, A., Xi, H., Marchese, C., Costa, M. (2024). Bioregionalization of the subarctic Pacific based on phytoplankton phenology and composition. Progress in Oceanography, 228, 103315, ISSN:0079-6611, doi: 10.1016/j.pocean.2024.103315.

Link: https://doi.org/10.1016/j.pocean.2024.103315

Keywords: 
Ocean colour; Biogeochemical regions; Phytoplankton phenology; Self-Organized Maps; Subarctic Pacific Ocean

Abstract:
The subarctic Pacific is generally perceived as relatively homogeneous since the North Pacific Subpolar Gyre dominates the water circulation in the area. However, previous research showed significant spatial differences in phytoplankton abundance and community structure. This study aimed to identify regions associated with distinct phytoplankton phenology and composition to comprehensively describe the main phytoplankton variability patterns across the subarctic Pacific. To this end, satellite GlobColour time series observations and an extensive in situ phytoplankton pigment dataset were used in the analysis. Five bioregions were identified, based on the Self-Organized Mapping technique, using a greater than 20-year satellite data series. The bioregions in the open Pacific waters were dominated by green algae, haptophytes, and pelagophytes and were divided into the areas affected by the North Pacific Transition Zone and beyond. The other bioregions were defined around the Pacific basin margins where the diatom contribution was generally higher, with a particular distinction of waters surrounding the Kuril and the Aleutian Islands. Our bioregion designations allow for future evaluation of the processes controlling the physical and biological dynamics within each bioregion, which has direct implications for foraging conditions available to higher trophic levels, including potential food resource competition.
